#!/bin/bash

rm -fr  mpiio_ssend mpiio_master_vector mpiio_master_subarray mpiio_bcast mpiio_individual mpiio_read_vector mpiio_read_subarray mpiio_readall_vector mpiio_readall_subarray 

