#!/bin/bash

cc -g -o mpiio_ssend mpiio_ssend.c ioutils.c arralloc.c
cc -g -o mpiio_master_vector mpiio_master_vector.c ioutils.c arralloc.c
cc -g -o mpiio_master_subarray mpiio_master_subarray.c ioutils.c arralloc.c
cc -g -o mpiio_bcast mpiio_bcast.c ioutils.c arralloc.c
cc -g -o mpiio_individual mpiio_individual.c ioutils.c arralloc.c
cc -g -o mpiio_read_vector mpiio_read_vector.c ioutils.c arralloc.c
cc -g -o mpiio_read_subarray mpiio_read_subarray.c ioutils.c arralloc.c
cc -g -o mpiio_readall_vector mpiio_readall_vector.c ioutils.c arralloc.c
cc -g -o mpiio_readall_subarray mpiio_readall_subarray.c ioutils.c arralloc.c

