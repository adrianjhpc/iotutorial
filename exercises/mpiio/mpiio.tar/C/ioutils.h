/*
 *  The maximum length of a file name
 */

#define MAXFILENAME 200

void initarray(void *ptr, int nx, int ny);
void initpgrid(void *ptr,int nxproc, int nyproc);

void checkandgetarguments(int argc, char **argv, int *nx, int *ny, int *xprocs, int *yprocs, int *nxp, int *nyp, int size, int rank);
void dotimings(double totaltime, int rank,int size);

void createfilename(char *filename, char *basename, int nx, int ny, int rank);

void ioread (char *filename, void *ptr, int nfloat);
void iowrite(char *filename, void *ptr, int nfloat);

void iochunkread (char *filename, void *ptr, int nfloat, long int offset);
void iochunkwrite(char *filename, void *ptr, int nfloat, long int offset);
