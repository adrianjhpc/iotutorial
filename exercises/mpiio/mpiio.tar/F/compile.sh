#!/bin/bash
ftn -o mpiio_bcast mpiio_bcast.f90 ioutils.f90
ftn -o mpiio_ssend mpiio_ssend.f90 ioutils.f90
ftn -o mpiio_individual mpiio_individual.f90 ioutils.f90
ftn -o mpiio_master_vector mpiio_master_vector.f90 ioutils.f90
ftn -o mpiio_master_subarray mpiio_master_subarray.f90 ioutils.f90
ftn -o mpiio_read_vector mpiio_read_vector.f90 ioutils.f90
ftn -o mpiio_read_subarray mpiio_read_subarray.f90 ioutils.f90
ftn -o mpiio_readall_vector mpiio_readall_vector.f90 ioutils.f90
ftn -o mpiio_readall_subarray mpiio_readall_subarray.f90 ioutils.f90
